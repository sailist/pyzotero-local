CREATE TRIGGER fki_collectionItems_libraryID  BEFORE INSERT ON collectionItems  FOR EACH ROW BEGIN    SELECT RAISE(ABORT, 'insert on table "collectionItems" violates foreign key constraint "fki_collectionItems_libraryID"')    WHERE (SELECT libraryID FROM collections WHERE collectionID = NEW.collectionID) != (SELECT libraryID FROM items WHERE itemID = NEW.itemID);  END;

