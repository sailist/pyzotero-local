CREATE TRIGGER fku_tags  BEFORE UPDATE OF name ON tags  FOR EACH ROW BEGIN      SELECT RAISE(ABORT, 'Tag cannot be blank')      WHERE TRIM(NEW.name)='';  END;

