CREATE TRIGGER fku_itemAttachments_parentItemID_collectionItems_itemID  BEFORE UPDATE OF parentItemID ON itemAttachments  FOR EACH ROW WHEN OLD.parentItemID IS NULL AND NEW.parentItemID IS NOT NULL BEGIN    DELETE FROM collectionItems WHERE itemID = NEW.itemID;  END;

