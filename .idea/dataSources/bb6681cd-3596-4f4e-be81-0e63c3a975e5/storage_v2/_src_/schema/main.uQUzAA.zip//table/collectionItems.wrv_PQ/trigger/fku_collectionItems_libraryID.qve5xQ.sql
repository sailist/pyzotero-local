CREATE TRIGGER fku_collectionItems_libraryID  BEFORE UPDATE ON collectionItems  FOR EACH ROW BEGIN    SELECT RAISE(ABORT, 'update on table "collectionItems" violates foreign key constraint "fku_collectionItems_libraryID"')    WHERE (SELECT libraryID FROM collections WHERE collectionID = NEW.collectionID) != (SELECT libraryID FROM items WHERE itemID = NEW.itemID);  END;

